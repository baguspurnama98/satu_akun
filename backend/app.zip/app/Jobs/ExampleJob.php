<?php

namespace App\Jobs;

class ExampleJob extends Job
{
    /**
     * https://lumen.laravel.com/docs/8.x/queues
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        //
    }
}
